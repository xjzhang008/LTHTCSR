%%
%clear all
addpath(genpath(cd));
randn('seed',2013);
randn('seed',2013);
%% load data
load('Akiyo_min.mat');
maxP1 = max(Akiyo_min(:));
X =Akiyo_min./max(Akiyo_min(:));

[d1,d2,d3,d4,d5] = size(X);
maxP = max(abs(X(:)));

Nways=size(X);
     
%% Set Omega
sr = 0.2                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                               ;  %% ssampling ratio \rho
fprintf('Sampling ratio = %0.8e\n',sr);
temp = randperm(prod(Nways));
kks = round((sr)*prod(Nways));
mark = zeros(Nways); 
M=ones(Nways);
barmark=ones(Nways)-mark;
mark(temp(1:kks)) = 1;
Y=X.*mark;
Ind=M.*mark;
shift_dim=[1,2,3,4,5];

[k1,k2,k3,k4,k5]=size(Y);
Y1=reshape(Y,k1,k2,k3*k4*k5);
Ind1=reshape(Ind,k1,k2,k3*k4*k5);
barmark=reshape(barmark,k1,k2,k3*k4*k5);

%% Interpolation
A = Y1;
B = padarray(A,[20,20,20],'symmetric','both');
C = padarray(Ind1,[20,20,20],'symmetric','both');
a1 = interpolate(shiftdim(B,1),shiftdim(C,1));
a1(a1<0) = 0;
a1(a1>1) = 1;
a1 = a1(21:end-20,21:end-20,21:end-20);
a1 = shiftdim(a1,2);
a1 = Y1+a1.*barmark;

a2 = interpolate(shiftdim(B,2),shiftdim(C,2));
a2(a2<0) = 0;
a2(a2>1) = 1;
a2 = a2(21:end-20,21:end-20,21:end-20);
a2 = shiftdim(a2,1);
a2 = Y1+a2.*barmark;
a = 0.5*a1+0.5*a2;
X0 = a;

X0=reshape(X0,size(Y));

X0= permute(X0,shift_dim);

XT = permute(X,shift_dim);
mark = permute(mark,shift_dim);
[n1, n2 ,n3,n4,n5] = size(XT);

%% Initial Parameters  
opts.alpha    = 80;
opts.beta     = 80;
opts.gamma    = 10;
opts.lambda   = 0.05;
opts.rho      = 0.001;
opts.max_iter = 1000;
opts.DEBUG    = 1;
opts.tol      = 2e-5;
%% LTHTCSR
fprintf('===== LTHTCSR =====\n');

U{1}=dct(eye(n1));U{2}=dct(eye(n2));%
U{1}=U{1}(1:140,:);U{2}=U{2}(1:160,:);
U{3}=dct(eye(n3));U{4}=dct(eye(n4));
U{4}=U{4}(1:12,:);
%U{5}=dct(eye(n5));
%U{5}=U{5}(1:10,:);
t0=tic; 

[Xhat,W,Y] =LTHTCSR(U,XT,mark,opts,X0);  %% LTHTCSR
%[Xhat,W] = LTHTC(U,XT,mark,opts,X0);  %% LTHTC
%[Xhat,W] = HTCSR(U,XT,mark,opts,X0);  %% HTCSR

time = toc(t0);
fprintf('CPU Time = %.4f\n',time);
Xhat1=max(0,Xhat);
Xhat=min(maxP,Xhat1);
Xhat=permute(Xhat,shift_dim);
%% Print the Relative Error, PSNR, SSIM and SAM
Error = norm(Xhat(:)-X(:))/norm(X(:));
fprintf('Relative error = %0.8e\n',Error);
psnr_index = PSNR_H(Xhat,X,maxP);  
[psnr,ssim,~]=quality(Xhat*maxP1,X*maxP1);
% sam = SAM3D(Xhat, X);
fprintf('PSNR = %.4f, SSIM = %.4f\n',psnr, ssim);
% %% Visualization
%     figure(1);
%     imshow(X(:,:,:,8))
%     figure(2);
%     imshow(Xhat(:,:,:,8))
%     figure(3);
%     imshow(Y(:,:,:,8))