function psnr = PSNR_H(X1,X2,maxP)

X1 = max(0,X1);
X1 = min(maxP,X1);

X2 = max(0,X2);
X2 = min(maxP,X2);

MSE = (norm(X1(:)-X2(:))^2)/ numel(X2);
psnr = 10*log10(maxP^2/MSE);