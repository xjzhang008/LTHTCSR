function [X,W,Y] =LTHTCSR(D,M,Omega,opts,X0)



% --------------------------------------------
% Input:
%           D   -    semi-orthogonal transform 
%           M      -    Order-d tensor
%           X0     -    Order-d tensor after interpolation
%           Omega   -    index of the observed entries
%           opts    -    Structure value in Matlab. The fields are
%           opts.tol             -   termination tolerance
%           opts.max_iter   -   maximum number of iterations
%           opts.DEBUG     -   0 or 1
%
% Output:
%       X                   -    Order-D tensor




%inner=10;
DEBUG = 1;

if ~exist('opts', 'var')
    opts = [];
end    
if isfield(opts, 'tol');         tol = opts.tol;              end
if isfield(opts, 'max_iter');    max_iter = opts.max_iter;    end
if isfield(opts, 'alpha');       alpha = opts.alpha;          end
if isfield(opts, 'beta');        beta = opts.beta;            end
if isfield(opts, 'gamma');       gamma = opts.gamma;          end
if isfield(opts, 'lambda');      lambda = opts.lambda;        end
if isfield(opts, 'DEBUG');       DEBUG = opts.DEBUG;          end
if isfield(opts, 'rho');         rho = opts.rho;              end

dim = size(M);
p = length(size(M));
n = zeros(1,p);
for i = 1:p
    n(i) = size(M,i);
end
inner=20;
BarOmega = ones(dim) - Omega;
X =X0;%Y=
Z=X;
for i=p:-1:3
    Z=tmprod(Z,D{i},i);
end
%Z=tmprod(Z,D{3},3);
n_d=1;
for i = 1:p-1
    n_d = n_d*size(Z,i);
end
Y = tanh(Z);
W=Z;
for i=1:2
    W=tmprod(W,D{i},i);
end

disp(size(Z))
disp(size(W))
Dim=size(Z);
%B{1}=dct(eye(n(3)));B{2}=dct(eye(n(4)));
for iter = 1 : max_iter
    Xk = X;
    

    % updata X
    X_temp=Z;
    for i=3:p
        X_temp=tmprod(X_temp,D{i}',i);
    end
    X=(alpha* X_temp+rho*X)./(alpha+rho);
    X=X.*BarOmega+M.*Omega;
    % updata Y
    Y_temp=(beta*tanh(Z)+rho*Y)./(beta+rho);
    [Y] =prox_NHTNN(Y_temp,1/(beta+rho));
    % updata Z
    Z_temp=X;
    W_temp=W;
    for i=1:2
        W_temp=tmprod( W_temp,D{i}',i);
    end
    
    for i=p:-1:3
        Z_temp=tmprod( Z_temp,D{i},i);
    end
      X_T=(alpha*Z_temp+rho*Z+gamma*W_temp)./(alpha+rho+gamma);
    
     Z = Newton1(Y, X_T,Z,inner,alpha+rho+gamma, beta);
    % updata W
    Z_temp=Z;
    for i=1:2
        Z_temp=tmprod(Z_temp,D{i},i);
    end
    
    W=(gamma*Z_temp+rho*W)/(gamma+rho);
    W=softThres(W,lambda/(gamma+rho));
    % updata U
    for t=3:p
    
        tempA=Z;
        for k=3:t-1
            tempA=tmprod(tempA,D{k}',k);
        end
        for k=p:-1:t+1
            tempA=tmprod(tempA,D{k}',k);
        end
        tempB=X;
        unA=Unfold(tempA,size(tempA),t);
        unB=Unfold(tempB,size(tempB),t);
        temp = alpha*unA*unB'+rho*D{t};
        [U,~,V]=svd(temp,"econ");
        D{t}=U*V';
  
    end 
     for t=1:2
    
        tempA=W;
        for k=1:t-1
            tempA=tmprod(tempA,D{k}',k);
        end
        for k=2:-1:t+1
            tempA=tmprod(tempA,D{k}',k);
        end
        tempB=Z;
        unA=Unfold(tempA,size(tempA),t);
        unB=Unfold(tempB,size(tempB),t);
        temp = gamma*unA*unB'+rho*D{t};
        [U,~,V]=svd(temp,"econ");
        D{t}=U*V';
  
    end 
    psnr_index = PSNR_H(X,M,1);
   
    chgX    = norm(Xk(:)-X(:))/norm(Xk(:));

  
    if DEBUG
        if iter == 1 || mod(iter, 10) == 0
            err = chgX;
            disp(['iter ' num2str(iter) ', err=' num2str(err)  ',psnr=' num2str(psnr_index)]); 
           
           
        end
    end
    
     
    if chgX < tol&& chgX>0 && iter>10
            break;
    end

end
end
function Z  = Newton1(g,a,Z,inner,alpha, beta)
        i=0;
        relchg=1;
        tol=10^(-4);  
        while  i < inner  &&  relchg > tol 
                Zp=Z;
                Numer = beta .* (1 - tanh(Z).^2) .* (tanh(Z) - g) + alpha .* (Z - a);
                Denom = -2 .* beta .* tanh(Z) .* ( 1 - tanh(Z).^2) .* (tanh(Z) - g) + beta .* ( 1 - tanh(Z).^2).^2 + alpha;
                Z  = Z - Numer./Denom;
                relchg = norm(Z - Zp,'fro')/norm(Z,'fro');
                i=i+1;
        end
end

function Z  = Newton2(g,a,Z,inner,alpha, beta)
        i=0;
        relchg=1;
        tol=10^(-4);  
        while  i < inner  &&  relchg > tol 
                Zp=Z;
                Numer = beta .* sigmoid(Z) .*(1 - sigmoid(Z)).* (sigmoid(Z) - g) + alpha .* (Z - a);
                Denom =  beta .* sigmoid(Z) .* ( 1 - sigmoid(Z)).^2 .* (sigmoid(Z) - g)+ beta .*(sigmoid(Z).^2).*( 1 - sigmoid(Z)) + alpha;
                Z  = Z - Numer./Denom;
                relchg = norm(Z - Zp,'fro')/norm(Z,'fro');
                i=i+1; 
        end
end

function Z  = Newton3(g,a,Z,inner,alpha, beta)
        i=0;
        relchg=1;
        tol=10^(-4);  
        while  i < inner  &&  relchg > tol 
                Zp=Z;
                Numer = beta .*cosh(Z).*(sinh(Z) - g) + alpha .* (Z - a);
                Denom =  beta .*sinh(Z).*(sinh(Z)-g)+ beta .*cosh(Z).^2 + alpha;
                Z  = Z - Numer./Denom;
                relchg = norm(Z - Zp,'fro')/norm(Z,'fro');
                i=i+1; 
        end
end


function x = softThres(a,tau)

x=sign(a).*max(abs(a)-tau,0);
end

