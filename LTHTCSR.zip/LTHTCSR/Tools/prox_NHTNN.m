function [X] = prox_NHTNN(Y,rho)


p = length(size(Y));
n = zeros(1,p);
for i = 1:p
    n(i) = size(Y,i);
end
X = zeros(n);


L = ones(1,p);
for i = 3:p
    L(i) = L(i-1) * n(i);
end


       
for i=1:L(p)
[U,S,V] = svd(Y(:,:,i),'econ');
S = diag(S);
r = length(find(S>rho));
if r>=1
    S =max( S(1:r)-rho,0);
    X(:,:,i) = U(:,1:r)*diag(S)*V(:,1:r)';
end
end



end

